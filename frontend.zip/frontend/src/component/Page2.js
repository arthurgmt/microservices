import React from 'react';
import SignIn from './SignIn';

function Page2() {
  return (
    <div>
      <SignIn />
    </div>
  );
}

export default Page2;
