import React from 'react';

function Home() {
  return (
    <div>
      <h1>Page d'accueil</h1>
      <p>Bienvenue sur notre site !</p>
    </div>
  );
}

export default Home;
